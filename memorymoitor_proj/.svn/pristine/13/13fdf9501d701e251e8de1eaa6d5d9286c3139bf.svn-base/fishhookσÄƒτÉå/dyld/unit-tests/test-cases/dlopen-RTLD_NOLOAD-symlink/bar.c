int bar() { return 0; }
