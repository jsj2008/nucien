
void foo() {}

