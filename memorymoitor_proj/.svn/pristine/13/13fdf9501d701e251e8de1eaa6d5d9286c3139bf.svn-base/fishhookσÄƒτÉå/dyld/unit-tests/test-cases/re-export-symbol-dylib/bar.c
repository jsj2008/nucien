
int bar(void)
{
	return 2;
}
