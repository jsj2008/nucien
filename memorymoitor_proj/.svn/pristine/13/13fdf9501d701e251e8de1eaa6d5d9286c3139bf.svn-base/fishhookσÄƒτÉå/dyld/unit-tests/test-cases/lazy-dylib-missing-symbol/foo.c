

int foo() 
{ 
    return 1; 
}

#if BAR
int bar() 
{ 
	return 1; 
}
#endif


