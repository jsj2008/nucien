# DEPRECATED

This project is deprecated because another is more advanced; please visit https://github.com/eternicode/bootstrap-datepicker