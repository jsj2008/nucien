  //
//  mallochook.c
//  memorydemo
//
//  Created by michaelbi on 16/10/11.
//  Copyright © 2016年 tencent. All rights reserved.
//

#include "mallochook.h"
#import "fishhook.h"
#import "FBAllocationTracker/FBAllocationTrackerManager.h"
#import  <dlfcn.h>
#include <stdio.h>
#include <stdlib.h>
#include <mach/mach.h>
#include <mach/machine/thread_status.h>
#include <pthread.h>
#include <malloc/malloc.h>
#include <libkern/OSSpinLockDeprecated.h>
#import <mach/mach_init.h>
#import <sys/mman.h>
#include <execinfo.h>
#include <string.h>
#import <mach-o/dyld.h>
#import <dlfcn.h>

AllStackInfo allStackInfo;


void stackInfo_Init() {
    allStackInfo.stackNum = 0;
}

void stackInfo_pushStack() {
    allStackInfo.stack[allStackInfo.stackNum].lineNum = 0;
    allStackInfo.stackNum++;
}

void stackInfo_pushStackInfo(char *info) {
    strcpy(allStackInfo.stack[allStackInfo.stackNum - 1].info[allStackInfo.stack[allStackInfo.stackNum - 1].lineNum], info);
    allStackInfo.stack[allStackInfo.stackNum - 1].lineNum++;
}


static NSMutableArray * freearray;
NSLock *writeLock;
OSSpinLock spinlock = OS_SPINLOCK_INIT;
OSSpinLock malloclock=OS_SPINLOCK_INIT;

struct mallocinfo_t {
    vm_address_t address;
    uint32_t size;
    char* name;
} mallocinfo[1024*100];

typedef struct{
    int frames;
    void* stack[128];
}CallBackStack;

typedef struct{
    const char* name;
    long loadAddr;
    long beginAddr;
    long endAddr;
}StackImage;
StackImage allstackimage[1024*100];




int malloccnt = 0;
int allimagecount = 0;
void* sign[3]={-1,-1,-1};
int signalcnt=0;
int signall=0;

void printmallocinf(struct mallocinfo_t tmp) {
    printf("address : %p, size : %u,  name : %s .\n", tmp.address, tmp.size, tmp.name);
    //fprintf(logfile, "address : %p, size : %u,  name : %s .\n", tmp.address, tmp.size, tmp.name);
}
void recordMallocStack(vm_address_t address,uint32_t size,const char*name,size_t stack_num_to_skip);
static void* (*orig_malloc) (size_t size, const void *caller);
static void (*orig_free) (void *ptr, const void *caller);
void getImageByAddr(long addr,StackImage *image);
static bool didHookOriginalMethods = false;
void initallstackimage();

void save_original_symbols() {
    orig_malloc = dlsym(RTLD_DEFAULT, "malloc");
    orig_free = dlsym(RTLD_DEFAULT, "free");
}

void *my_malloc (size_t size, const void *caller){
    //OSSpinLockLock(&malloclock);
    void * result;
    result = orig_malloc(size,caller);
   
    if (size ==(sizeof(int)*137)){
        sign[signalcnt++] =result;
        signall++;
        NSThread *current = [NSThread currentThread];
        NSLog(@"malloc thread is %@",current);
        //puts("malloc sleep");
        //sleep(100);
    }
//    if(morefunction){
//        sleep(1000);
//    }
    if(didHookOriginalMethods){
        //printf("Calling real malloc result is %p size is %zu\n",result, size);
        //printf("%s",object_getClassName((__bridge id)(result)));
        //[[FBAllocationTrackerManager sharedManager] incrementAllocations:(__bridge id)result];
        recordMallocStack((vm_address_t)result, (uint32_t)size,"malloc",2);
        //printf("s_________");
    }
    //OSSpinLockUnlock(&malloclock);
    return result;
}



void my_free(void *ptr, const void *caller)
{
    //OSSpinLockLock(&malloclock);
    //size_t size = sizeof(*ptr);
    if(ptr == sign[0] || ptr == sign[1] || ptr == sign[2]){
        //sleep(1000);
        NSThread *current = [NSThread currentThread];
        NSLog(@"free thread is %@",current);
        //printf("%x",sign[0]);
    }
    orig_free(ptr,caller);
    //printf ("freed pointer %p\n", ptr);
    //OSSpinLockUnlock(&malloclock);
}


void turnOnMallocTracker(void){
    if(didHookOriginalMethods){
        return;
    }
    stackInfo_Init();
    freearray = [[NSMutableArray alloc]init];
    writeLock = [[NSLock alloc] init];
    didHookOriginalMethods =true;
    save_original_symbols();
    initallstackimage();
    rebind_symbols((struct rebinding[2]){{"malloc",my_malloc},{"free",my_free}}, 2);
    //rebind_symbols((struct rebinding[1]){{"malloc",my_malloc}}, 1);
}

void turnOffMallocTracker(void){
    if(!didHookOriginalMethods){
        return;
    }
    didHookOriginalMethods =false;
    allimagecount=0;
}


void recordMallocStack(vm_address_t address,uint32_t size,const char*name,size_t stack_num_to_skip)
{
    
    CallBackStack callStack;
    callStack.frames = backtrace(callStack.stack, 128);
    //imagrarray[128];
    stackInfo_pushStack();
    for(int i = 0;i < callStack.frames;i++){
        long  addr = (long)callStack.stack[i];
        StackImage image;
        getImageByAddr(addr,&image);
        const char *namett = image.name;
//        NSArray *paths =NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,NSUserDomainMask, YES);
//        NSString *documentDirectory = [paths objectAtIndex:0];
//        NSString *fileName = [NSString stringWithFormat:@"dr.log"];//注意不是NSData!
//        NSString *logFilePath = [documentDirectory stringByAppendingPathComponent:fileName];
        char info[100];
        sprintf(info, "\"%d %s 0x%lx 0x%lx\",",(int)i, (namett != NULL) ? namett : "unknown", image.loadAddr, addr);
        stackInfo_pushStackInfo(info);
        //printf(info, "\"0x%lx 0x%lx\",", image.loadAddr, addr);
        //printf("\"0x%lx 0x%lx\",", image.loadAddr, addr);
        //printf("\"%s\",", namett);
        //printf("%s\n", info);
        //fopen(<#const char *restrict __filename#>, "w")
        //NSLog(@"lalalala");
        
    }
    return;
    //stackInfo;
    
    
//rosenluo
//void recordMallocStack(vm_address_t address,uint32_t size,const char*name,size_t stack_num_to_skip)
//{
//        base_stack_t base_stack;
//        base_ptr_log base_ptr;
//        unsigned char md5[16];
//        vm_address_t  *stack[max_stack_depth];
//        base_stack.depth = recordBacktrace(2,stack_num_to_skip, stack,md5);
//        if(base_stack.depth > 0){
//            base_stack.stack = (vm_address_t**)malloc_zone_malloc(memory_zone, base_stack.depth*sizeof(vm_address_t*));
//            memcpy(base_stack.stack, stack, base_stack.depth * sizeof(vm_address_t *));
//            base_stack.name = name;
//            base_ptr.md5 = md5;
//            base_ptr.size = size;
//            OSSpinLockLock(&hashmap_spinlock);
//            if(ptrs_hashmap && stacks_hashmap){
//                ptrs_hashmap->insertPtr(address, &base_ptr);
//                stacks_hashmap->insertStackAndIncreaseCountIfExist(md5, &base_stack);
//            }
//            OSSpinLockUnlock(&hashmap_spinlock);
//        }
//}
    
//        
//        OSSpinLockLock(&spinlock);
//        if(ptrs_hashmap && stacks_hashmap){
//            mallocinfo[malloccnt].name = name;
//            mallocinfo[malloccnt].address = address;
//            mallocinfo[malloccnt].size =size;
//            printmallocinf(mallocinfo[malloccnt++]);
//            ptrs_hashmap->insertPtr(address, &base_ptr);
//            stacks_hashmap->insertStackAndIncreaseCountIfExist(md5, &base_stack);
////        }
//        OSSpinLockUnlock(&spinlock);
//    }

}


void initallstackimage(){
        uint32_t count = _dyld_image_count();
        for (uint32_t i = 0; i < count; i++) {
            const mach_header_t* header = (const mach_header_t*)_dyld_get_image_header(i);
            const char* name = _dyld_get_image_name(i);
            const char* tmp = strrchr(name, '/');
            long slide = _dyld_get_image_vmaddr_slide(i);
            if (tmp) {
                name = tmp + 1;
            }
            
            long offset = (long)header + sizeof(mach_header_t);
            
            for (unsigned int i = 0; i < header->ncmds; i++) {
                const segment_command_t* segment = (const segment_command_t*)offset;
                if (segment->cmd == MY_SEGMENT_CMD_TYPE && strcmp(segment->segname, SEG_TEXT) == 0) {
                    long begin = (long)segment->vmaddr + slide;
                    long end = (long)(begin + segment->vmsize);
                    StackImage image;
                    image.loadAddr = (long)header;
                    image.beginAddr = begin;
                    image.endAddr = end;
                    image.name = name;
                    allstackimage[i]=image;
                    allimagecount++;
                    NSLog(@"image info %s begin %ld end %ld",name,begin,end);
                }
                offset += segment->cmdsize;
            }
        }
}

void getImageByAddr(long addr,StackImage *image){
    for (size_t i = 0; i < allimagecount; i++) {
        if (addr >= allstackimage[i].beginAddr && addr < allstackimage[i].endAddr) {
                 //     *image = allImages[i];
            image->name = allstackimage[i].name;
            image->loadAddr = allstackimage[i].loadAddr;
            image->beginAddr = allstackimage[i].beginAddr;
            image->endAddr = allstackimage[i].endAddr;
        }
    }
}
