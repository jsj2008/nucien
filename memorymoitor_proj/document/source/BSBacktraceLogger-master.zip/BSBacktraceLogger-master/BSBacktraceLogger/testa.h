//
//  testa.h
//  BsBacktraceLogger
//
//  Created by michaelbi on 17/1/1.
//  Copyright © 2017年 bestswifter. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface testa : NSObject

@end
