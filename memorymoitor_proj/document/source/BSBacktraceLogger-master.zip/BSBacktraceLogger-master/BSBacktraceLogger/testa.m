//
//  testa.m
//  BsBacktraceLogger
//
//  Created by michaelbi on 17/1/1.
//  Copyright © 2017年 bestswifter. All rights reserved.
//

#import "testa.h"

@implementation testa

- (void)bar1 {
    while (true) {
        ;
    }
}
@end
