//
//  Header.h
//  TabDemo
//
//  Created by jackyjiao on 7/9/15.
//  Copyright (c) 2015 jackyjiao. All rights reserved.
//

#import <UIKit/UIKit.h>

void enableIOHook();
void disableIOHook();