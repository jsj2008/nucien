//
//  ViewController.m
//  MemoryMonitor
//
//  Created by 王哲锴 on 17/1/15.
//  Copyright © 2017年 王哲锴. All rights reserved.
//

#import "ViewController.h"
#include <malloc/malloc.h>
#import "HeapMemory.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self test];
    getHeapPointer(1, 2);
    // Do any additional setup after loading the view, typically from a nib.
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)test{
    NSObject* test = [[NSObject alloc]init];
    malloc_printf("test - frist : 0x%016x\n", test);
    //test = nil;
    //    malloc_printf("test - second : 0x%016x\n", test);
    NSMutableString* test2 = [[NSMutableString alloc]initWithFormat:@"abcde"];
    //    malloc_printf("test2 - first : 0x%016x\n", test2);
    //    test2 = [[NSMutableArray alloc]init];
    
    
    
    char *a = malloc(sizeof(char) * 1024);
    //malloc_printf("test  : 0x%016x\n", test);
    malloc_printf("test2 : 0x%016x\n", test2);
    malloc_printf("a     : 0x%016x\n", a);
    free(a);
    //[test release];
    [test2 release];
}

@end
