//
//  HeapMemory.m
//  MIO
//
//  Created by 王哲锴 on 17/1/15.
//  Copyright © 2017年 王哲锴. All rights reserved.
//

#import "HeapMemory.h"
#import <Foundation/Foundation.h>
#include <objc/objc-api.h>
#include <objc/runtime.h>
#include <malloc/malloc.h>
#include <mach/mach.h>


static Class * internalClassList;
static uint64_t classCount;



typedef struct {
    Class isa;
} flex_maybe_object_t;

static Class * internalClassList;
static uint64_t classCount;

static kern_return_t memory_reader(task_t task, vm_address_t remote_address, vm_size_t size, void **local_memory)
{
    *local_memory = (void *)remote_address;
    return KERN_SUCCESS;
}


void CanHasObjects(task_t task, void * context, unsigned type, vm_range_t * addr, unsigned count) {
    for (uint64_t index = 0; index < count; index++) {
        vm_range_t range =  addr[index];
        flex_maybe_object_t *address = ((flex_maybe_object_t *)range.address);
        size_t size = range.size;
        if (size >= sizeof(Class) && address != NULL) {
            for (uint64_t lookupIndex = 0; lookupIndex < classCount; lookupIndex++) {
                Class testClass = (internalClassList[lookupIndex]);
                Class tryClass = NULL;
#ifdef __arm64__
                extern uint64_t objc_debug_isa_class_mask WEAK_IMPORT_ATTRIBUTE;
                tryClass = (__bridge Class)((void *)((uint64_t)address->isa & objc_debug_isa_class_mask));
#else
                tryClass = address->isa;
#endif
                if (tryClass == testClass) {
                    printf("0x%016x -- Class: %s\n",address, object_getClassName((__bridge id)address));
                    break;
                }
            }
        }
    }
}

int getHeapPointer(int argc , const char * argv[]) {
    
    internalClassList = objc_copyClassList(&classCount);
//    for(int i = 0; i < classCount; ++i) {
//        NSLog(@"ClassList : %@\n", internalClassList[i]);
//    }
    vm_address_t *zones = NULL;
    uint64_t count = 0;
    kern_return_t error = malloc_get_all_zones(mach_task_self(), &memory_reader, &zones, &count);
    if (error == KERN_SUCCESS) {
        for (uint64_t index = 0; index < count; index++) {
            malloc_zone_t *zone = (malloc_zone_t *)zones[index];
            if (zone->introspect && zone->introspect->enumerator) {
                zone->introspect->enumerator(mach_task_self(), NULL, MALLOC_PTR_IN_USE_RANGE_TYPE, zone, &memory_reader, &CanHasObjects);
            }
        }
    }
    return 0;
}

//+ (void)enumerateLiveObjectsUsingBlock:(flex_object_enumeration_block_t)block
//{
//    if (!block) {
//        return;
//    }
//    
//    // Refresh the class list on every call in case classes are added to the runtime.
//    [self updateRegisteredClasses];
//    
//    // For another exmple of enumerating through malloc ranges (which helped my understanding of the api) see:
//    // http://llvm.org/svn/llvm-project/lldb/tags/RELEASE_34/final/examples/darwin/heap_find/heap/heap_find.cpp
//    // Also https://gist.github.com/samdmarshall/17f4e66b5e2e579fd396
//    vm_address_t *zones = NULL;
//    unsigned int zoneCount = 0;
//    kern_return_t result = malloc_get_all_zones(mach_task_self(), &memory_reader, &zones, &zoneCount);
//    if (result == KERN_SUCCESS) {
//        for (unsigned int i = 0; i < zoneCount; i++) {
//            malloc_zone_t *zone = (malloc_zone_t *)zones[i];
//            if (zone->introspect && zone->introspect->enumerator) {
//                zone->introspect->enumerator(mach_task_self(), (__bridge void *)(block), MALLOC_PTR_IN_USE_RANGE_TYPE, zones[i], &memory_reader, &range_callback);
//            }
//        }
//    }
//}
//
//+ (void)updateRegisteredClasses
//{
//    if (!registeredClasses) {
//        registeredClasses = CFSetCreateMutable(NULL, 0, NULL);
//    } else {
//        CFSetRemoveAllValues(registeredClasses);
//    }
//    unsigned int count = 0;
//    Class *classes = objc_copyClassList(&count);
//    for (unsigned int i = 0; i < count; i++) {
//        CFSetAddValue(registeredClasses, (__bridge const void *)(classes[i]));
//    }
//    free(classes);
//}
//
//static void range_callback(task_t task, void *context, unsigned type, vm_range_t *ranges, unsigned rangeCount)
//{
//    flex_object_enumeration_block_t block = (__bridge flex_object_enumeration_block_t)context;
//    if (!block) {
//        return;
//    }
//    
//    for (unsigned int i = 0; i < rangeCount; i++) {
//        vm_range_t range = ranges[i];
//        flex_maybe_object_t *tryObject = (flex_maybe_object_t *)range.address;
//        Class tryClass = NULL;
//#ifdef __arm64__
//        // See http://www.sealiesoftware.com/blog/archive/2013/09/24/objc_explain_Non-pointer_isa.html
//        extern uint64_t objc_debug_isa_class_mask WEAK_IMPORT_ATTRIBUTE;
//        tryClass = (__bridge Class)((void *)((uint64_t)tryObject->isa & objc_debug_isa_class_mask));
//#else
//        tryClass = tryObject->isa;
//#endif
//        // If the class pointer matches one in our set of class pointers from the runtime, then we should have an object.
//        if (CFSetContainsValue(registeredClasses, (__bridge const void *)(tryClass))) {
//            block((__bridge id)tryObject, tryClass);
//        }
//    }
//}
