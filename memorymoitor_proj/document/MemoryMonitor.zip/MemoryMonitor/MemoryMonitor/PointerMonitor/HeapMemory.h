//
//  HeapMemory.h
//  MIO
//
//  Created by 王哲锴 on 17/1/15.
//  Copyright © 2017年 王哲锴. All rights reserved.
//

#ifndef HeapMemory_h
#define HeapMemory_h


#endif /* HeapMemory_h */

#import <Foundation/Foundation.h>

@interface HeapMemory : NSObject

@end

int getHeapPointer(int argc , const char * argv[]);
