//
//  GlobalMemory.h
//  MIO
//
//  Created by 王哲锴 on 17/1/15.
//  Copyright © 2017年 王哲锴. All rights reserved.
//

#ifndef GlobalMemory_h
#define GlobalMemory_h


#endif /* GlobalMemory_h */

#import <Foundation/Foundation.h>

@interface GlobalMemory : NSObject


+ (void) getGlobalVariableMemory;


@end
